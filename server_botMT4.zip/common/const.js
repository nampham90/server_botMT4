const  idKhachhang = "632ebaf77e9ad9aeef4e3d27";
const  idTaixe = "636cf775974c56587047691e";
const  ip = "117.2.198.251";
const  mauvang = "\xF0\x9F\x8C\x95 ";
const  lengthId = 24;
const  hangdi = "0";
const  hangve = "1";
const  emailAdmin = "namandroid.it@gmail.com";
const  MSGerrorsystem = "Lỗi hệ thống !";
const  MSGsucessystem = 'Data Sucess !'


module.exports = {
    idKhachhang,
    idTaixe,
    ip,
    mauvang,
    lengthId,
    hangdi,
    hangve,
    emailAdmin,
    MSGerrorsystem,
    MSGsucessystem
}
